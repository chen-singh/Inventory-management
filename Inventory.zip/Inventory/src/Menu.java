import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Menu {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        ItemManager itemManager=new ItemManager();
        int  choice;

        do {
            System.out.println("1.Add");
            System.out.println("2.update");
            System.out.println("3.delete");
            System.out.println("4.view");
            System.out.println("5.Exit...");
            System.out.println("Enter choice ");
            choice=sc.nextInt();
            switch (choice){
                case 1:itemManager.addItem();break;
                case 2:itemManager.updateStock();break;
                case 3:itemManager.deleteStock();break;
                case 4:itemManager.viewStock();break;
                case 5 : System.exit(0);break;
                default:
                    System.out.println("Invalid choice ");
                    break;
            }


        }while (choice!=5);
    }
}