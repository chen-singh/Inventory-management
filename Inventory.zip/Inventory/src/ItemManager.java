import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ItemManager{
    List<Item> items=new ArrayList<>();
    Scanner sc=new Scanner(System.in);

    boolean found;
    public void saveToFile(){
        try(FileWriter writer=new FileWriter("items.txt")){
            for (Item item:items){
                writer.write(item.getId()+"  "+ item.getName()+"  "+item.getQuantity()+"  "+item.getPrice());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public void addItem(){
        System.out.println("Enter Id");
        int  id= sc.nextInt();
        System.out.println("Enter name");
        String name=sc.next();
        System.out.println("Enter quantity");
        int quantity=sc.nextInt();
        System.out.println("Enter price");
        double price=sc.nextDouble();
        items.add(new Item(id,name,quantity,price));
        saveToFile();
        System.out.println("Item added");

        if (quantity<5){
            System.out.println("*****  Alert  Increase stock  *****");
        }
    }
    public void updateStock(){
        found=false;
        System.out.println("Enter id");
        int id= sc.nextInt();
        for (Item item:items) {
            if (item.getId()==id){
                System.out.println("Enter name ");
                String name=sc.next();
                System.out.println("Enter quantities");
                int quantites= sc.nextInt();
                System.out.println("Enter price");
                double price=sc.nextDouble();
                item.setName(name);
                item.setQuantity(quantites);
                item.setPrice(price);
                found=true;

            }
            System.out.println("Stock updated ");
            if (item.getQuantity()<5){
                System.out.println("**** Alert  Increase Stock  ****");
            }
        }


        if (!found){
            System.out.println("There is no item for this id :");
        }


    }
    public void deleteStock(){
        found=false;
        System.out.println("Enter id");
        int id=sc.nextInt();
        Iterator<Item> iterator= items.iterator();
        while (iterator.hasNext()) {
            Item item = iterator.next();
            if (item.getId() == id) {
                iterator.remove();
                System.out.println(" Item removed");
                found=true;
            }
        }
        if (!found){
            System.out.println("there is no item of this id ");
        }


    }
    public void viewStock() {
        found=false;
        for (Item item:items){
            System.out.println(item.getId()+"  "+item.getName()+"  "+item.getQuantity()+"  "+item.getPrice());
            found=true;
            if (item.getQuantity()<5){
                System.out.println("**** Alert Increase stock  ****");
            }
        }if (!found){
            System.out.println("There is nothing to view ");
        }
    }
}

